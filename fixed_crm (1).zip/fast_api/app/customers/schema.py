from datetime import datetime

from pydantic import BaseModel, EmailStr, Field


class CustomerCreate(BaseModel):
    full_name: str = Field(
        ...,
        min_length=2,
        max_length=255,
    )

    email: EmailStr

    phone: str | None = None

    is_active: bool = True


class CustomerUpdate(BaseModel):
    full_name: str | None = Field(
        None,
        min_length=2,
        max_length=255,
    )

    email: EmailStr | None = None

    phone: str | None = None

    is_active: bool | None = None


class CustomerRead(BaseModel):
    id: int
    full_name: str
    email: str
    phone: str | None
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = {
        "from_attributes": True
    }


class CustomerListResponse(BaseModel):
    total: int
    items: list[CustomerRead]