from datetime import datetime

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.customers.model import Customer
from app.customers.schema import CustomerCreate, CustomerUpdate


def create_customer(
    db: Session,
    data: CustomerCreate,
) -> Customer:

    existing = db.execute(
        select(Customer).where(
            func.lower(Customer.email) == data.email.lower()
        )
    ).scalar_one_or_none()

    if existing:
        raise HTTPException(
            status_code=409,
            detail="Email already registered",
        )

    customer = Customer(
        **data.model_dump()
    )

    db.add(customer)

    try:
        db.commit()
        db.refresh(customer)
    except IntegrityError:
        db.rollback()

        raise HTTPException(
            status_code=409,
            detail="Email already registered",
        )

    return customer


def get_customer(
    db: Session,
    customer_id: int,
) -> Customer:

    customer = db.get(Customer, customer_id)

    if not customer:
        raise HTTPException(
            status_code=404,
            detail="Customer not found",
        )

    return customer


def list_customers(
    db: Session,
    is_active: bool | None = None,
    email_contains: str | None = None,
    full_name_contains: str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    page: int = 1,
    page_size: int = 20,
):
    query = select(Customer)

    if is_active is not None:
        query = query.where(
            Customer.is_active == is_active
        )

    if email_contains is not None:
        query = query.where(
            Customer.email.ilike(
                f"%{email_contains}%"
            )
        )

    if full_name_contains is not None:
        query = query.where(
            Customer.full_name.ilike(
                f"%{full_name_contains}%"
            )
        )

    if created_after is not None:
        query = query.where(
            Customer.created_at >= created_after
        )

    if created_before is not None:
        query = query.where(
            Customer.created_at <= created_before
        )

    count_query = select(
        func.count()
    ).select_from(
        query.subquery()
    )

    total = db.execute(
        count_query
    ).scalar_one()

    offset = (page - 1) * page_size

    items = db.execute(
        query
        .order_by(Customer.created_at.desc())
        .offset(offset)
        .limit(page_size)
    ).scalars().all()

    return {
        "total": total,
        "items": items,
    }


def patch_customer(
    db: Session,
    customer_id: int,
    data: CustomerUpdate,
) -> Customer:

    customer = get_customer(
        db,
        customer_id,
    )

    updates = data.model_dump(
        exclude_unset=True
    )

    if "email" in updates:
        existing = db.execute(
            select(Customer).where(
                func.lower(Customer.email)
                == updates["email"].lower(),
                Customer.id != customer_id,
            )
        ).scalar_one_or_none()

        if existing:
            raise HTTPException(
                status_code=409,
                detail="Email already in use",
            )

    for field, value in updates.items():
        setattr(
            customer,
            field,
            value,
        )

    try:
        db.commit()
        db.refresh(customer)
    except IntegrityError:
        db.rollback()

        raise HTTPException(
            status_code=409,
            detail="Email already in use",
        )

    return customer


def delete_customer(
    db: Session,
    customer_id: int,
    soft: bool = False,
):

    customer = get_customer(
        db,
        customer_id,
    )

    if soft:
        customer.is_active = False

        db.commit()

        return

    try:
        db.delete(customer)
        db.commit()

    except IntegrityError:
        db.rollback()

        raise HTTPException(
            status_code=409,
            detail="Cannot delete customer with active leads",
        )