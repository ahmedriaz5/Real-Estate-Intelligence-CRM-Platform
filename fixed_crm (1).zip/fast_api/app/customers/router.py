from datetime import datetime

from fastapi import APIRouter, Depends, Query, Response, status
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.core.dependencies import require_admin, require_agent_or_admin
from app.customers import service
from app.customers.schema import (
    CustomerCreate,
    CustomerListResponse,
    CustomerRead,
    CustomerUpdate,
)
from app.database import get_db
from app.users.model import User


router = APIRouter()


@router.get("", response_model=CustomerListResponse)
def list_customers(
    is_active: bool | None = Query(None),
    email_contains: str | None = Query(None),
    full_name_contains: str | None = Query(None),
    created_after: datetime | None = Query(None),
    created_before: datetime | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    return service.list_customers(
        db=db,
        is_active=is_active,
        email_contains=email_contains,
        full_name_contains=full_name_contains,
        created_after=created_after,
        created_before=created_before,
        page=page,
        page_size=page_size,
    )


@router.get("/{customer_id}", response_model=CustomerRead)
def get_customer(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    return service.get_customer(db, customer_id)


@router.post(
    "",
    response_model=CustomerRead,
    status_code=status.HTTP_201_CREATED,
)
def create_customer(
    data: CustomerCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    return service.create_customer(db, data)


@router.patch("/{customer_id}", response_model=CustomerRead)
def patch_customer(
    customer_id: int,
    data: CustomerUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    return service.patch_customer(db, customer_id, data)


@router.delete(
    "/{customer_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_customer(
    customer_id: int,
    settings: Settings = Depends(get_settings),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    service.delete_customer(
        db,
        customer_id,
        soft=settings.enable_soft_delete,
    )

    return Response(status_code=204)
