from decimal import Decimal

from fastapi import APIRouter, Depends, Query, Response, status
from sqlalchemy.orm import Session

from app.core.dependencies import require_admin, require_agent_or_admin
from app.database import get_db
from app.properties import service
from app.properties.schema import (
    PropertyCreate,
    PropertyListResponse,
    PropertyRead,
    PropertyUpdate,
)
from app.users.model import User


router = APIRouter()


@router.get("", response_model=PropertyListResponse)
def list_properties(
    city: str | None = Query(None),
    property_type: str | None = Query(None),
    min_price: Decimal | None = Query(None),
    max_price: Decimal | None = Query(None),
    min_bedrooms: int | None = Query(None, ge=0),
    is_available: bool | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    return service.list_properties(
        db=db,
        city=city,
        property_type=property_type,
        min_price=min_price,
        max_price=max_price,
        min_bedrooms=min_bedrooms,
        is_available=is_available,
        page=page,
        page_size=page_size,
    )


@router.get("/{property_id}", response_model=PropertyRead)
def get_property(
    property_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    return service.get_property(db, property_id)


@router.post(
    "",
    response_model=PropertyRead,
    status_code=status.HTTP_201_CREATED,
)
def create_property(
    data: PropertyCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    return service.create_property(db, data)


@router.patch("/{property_id}", response_model=PropertyRead)
def patch_property(
    property_id: int,
    data: PropertyUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    return service.patch_property(db, property_id, data)


@router.delete(
    "/{property_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_property(
    property_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    service.delete_property(db, property_id)

    return Response(status_code=204)
