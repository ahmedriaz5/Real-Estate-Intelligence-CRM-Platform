from datetime import datetime
from decimal import Decimal

from pydantic import BaseModel, Field


class PropertyCreate(BaseModel):
    title: str = Field(
        ...,
        min_length=2,
        max_length=255,
    )

    city: str = Field(
        ...,
        min_length=2,
        max_length=100,
    )

    address: str = Field(
        ...,
        min_length=2,
        max_length=500,
    )

    price: Decimal = Field(
        ...,
        gt=0,
    )

    bedrooms: int = Field(
        ...,
        ge=0,
    )

    property_type: str = Field(
        ...,
        min_length=2,
        max_length=50,
    )

    is_available: bool = True


class PropertyUpdate(BaseModel):
    title: str | None = Field(
        None,
        min_length=2,
        max_length=255,
    )

    city: str | None = Field(
        None,
        min_length=2,
        max_length=100,
    )

    address: str | None = Field(
        None,
        min_length=2,
        max_length=500,
    )

    price: Decimal | None = Field(
        None,
        gt=0,
    )

    bedrooms: int | None = Field(
        None,
        ge=0,
    )

    property_type: str | None = Field(
        None,
        min_length=2,
        max_length=50,
    )

    is_available: bool | None = None


class PropertyRead(BaseModel):
    id: int
    title: str
    city: str
    address: str
    price: Decimal
    bedrooms: int
    property_type: str
    is_available: bool
    created_at: datetime
    updated_at: datetime

    model_config = {
        "from_attributes": True
    }


class PropertyListResponse(BaseModel):
    total: int
    items: list[PropertyRead]