from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.properties.model import Property
from app.properties.schema import (
    PropertyCreate,
    PropertyUpdate,
)


def create_property(
    db: Session,
    data: PropertyCreate,
) -> Property:

    property_obj = Property(
        **data.model_dump()
    )

    db.add(property_obj)

    try:
        db.commit()
        db.refresh(property_obj)
    except IntegrityError:
        db.rollback()

        raise HTTPException(
            status_code=409,
            detail="Could not create property",
        )

    return property_obj


def get_property(
    db: Session,
    property_id: int,
) -> Property:

    property_obj = db.get(
        Property,
        property_id,
    )

    if not property_obj:
        raise HTTPException(
            status_code=404,
            detail="Property not found",
        )

    return property_obj


def list_properties(
    db: Session,
    city: str | None = None,
    property_type: str | None = None,
    min_price: Decimal | None = None,
    max_price: Decimal | None = None,
    min_bedrooms: int | None = None,
    is_available: bool | None = None,
    page: int = 1,
    page_size: int = 20,
):

    query = select(Property)

    if city is not None:
        query = query.where(
            func.lower(Property.city)
            == city.lower()
        )

    if property_type is not None:
        query = query.where(
            Property.property_type
            == property_type
        )

    if min_price is not None:
        query = query.where(
            Property.price >= min_price
        )

    if max_price is not None:
        query = query.where(
            Property.price <= max_price
        )

    if min_bedrooms is not None:
        query = query.where(
            Property.bedrooms >= min_bedrooms
        )

    if is_available is not None:
        query = query.where(
            Property.is_available == is_available
        )

    count_query = select(
        func.count()
    ).select_from(
        query.subquery()
    )

    total = db.execute(
        count_query
    ).scalar_one()

    offset = (page - 1) * page_size

    items = db.execute(
        query
        .order_by(Property.created_at.desc())
        .offset(offset)
        .limit(page_size)
    ).scalars().all()

    return {
        "total": total,
        "items": items,
    }


def patch_property(
    db: Session,
    property_id: int,
    data: PropertyUpdate,
) -> Property:

    property_obj = get_property(
        db,
        property_id,
    )

    updates = data.model_dump(
        exclude_unset=True
    )

    for field, value in updates.items():
        setattr(
            property_obj,
            field,
            value,
        )

    db.commit()
    db.refresh(property_obj)

    return property_obj


def delete_property(
    db: Session,
    property_id: int,
):

    property_obj = get_property(
        db,
        property_id,
    )

    try:
        db.delete(property_obj)
        db.commit()

    except IntegrityError:
        db.rollback()

        raise HTTPException(
            status_code=409,
            detail="Could not delete property",
        )