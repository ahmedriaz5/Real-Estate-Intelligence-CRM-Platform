from datetime import datetime

from fastapi import APIRouter, Depends, Query, Response, status
from sqlalchemy.orm import Session

from app.core.dependencies import require_admin, require_agent_or_admin
from app.database import get_db
from app.leads import service
from app.leads.schema import (
    LeadCreate,
    LeadListResponse,
    LeadRead,
    LeadUpdate,
)
from app.users.model import User


router = APIRouter()


@router.get("", response_model=LeadListResponse)
def list_leads(
    status: str | None = Query(None),
    agent_id: int | None = Query(None),
    customer_id: int | None = Query(None),
    property_id: int | None = Query(None),
    created_after: datetime | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    return service.list_leads(
        db=db,
        status=status,
        agent_id=agent_id,
        customer_id=customer_id,
        property_id=property_id,
        created_after=created_after,
        page=page,
        page_size=page_size,
    )


@router.get("/{lead_id}", response_model=LeadRead)
def get_lead(
    lead_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    return service.get_lead_detail(db, lead_id)


@router.post(
    "",
    response_model=LeadRead,
    status_code=status.HTTP_201_CREATED,
)
def create_lead(
    data: LeadCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    lead = service.create_lead(db, data)

    return service.get_lead_detail(db, lead.id)


@router.patch("/{lead_id}", response_model=LeadRead)
def patch_lead(
    lead_id: int,
    data: LeadUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_agent_or_admin),
):
    service.patch_lead(db, lead_id, data)

    return service.get_lead_detail(db, lead_id)


@router.delete(
    "/{lead_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_lead(
    lead_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    service.delete_lead(db, lead_id)

    return Response(status_code=204)
