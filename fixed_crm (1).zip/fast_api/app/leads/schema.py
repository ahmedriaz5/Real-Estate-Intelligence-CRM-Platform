from datetime import datetime

from pydantic import BaseModel, Field

from app.customers.schema import CustomerRead
from app.properties.schema import PropertyRead


class LeadCreate(BaseModel):
    customer_id: int = Field(..., gt=0)
    property_id: int | None = Field(None, gt=0)
    agent_id: int | None = Field(None, gt=0)
    status: str = "new"
    notes: str | None = Field(
        None,
        max_length=2000,
    )


class LeadUpdate(BaseModel):
    customer_id: int | None = Field(None, gt=0)
    property_id: int | None = Field(None, gt=0)
    agent_id: int | None = Field(None, gt=0)
    status: str | None = None
    notes: str | None = Field(
        None,
        max_length=2000,
    )


class LeadRead(BaseModel):
    id: int
    customer_id: int
    property_id: int | None
    agent_id: int | None
    status: str
    notes: str | None
    created_at: datetime
    updated_at: datetime

    customer: CustomerRead
    property: PropertyRead | None

    model_config = {
        "from_attributes": True
    }


class LeadListRead(BaseModel):
    id: int
    customer_id: int
    property_id: int | None
    agent_id: int | None
    status: str
    notes: str | None
    created_at: datetime
    updated_at: datetime

    model_config = {
        "from_attributes": True
    }


class LeadListResponse(BaseModel):
    total: int
    items: list[LeadListRead]