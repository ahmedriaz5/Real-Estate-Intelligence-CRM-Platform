from datetime import datetime

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from app.customers.model import Customer
from app.leads.model import Lead, LeadStatus
from app.leads.schema import LeadCreate, LeadUpdate
from app.properties.model import Property


def create_lead(
    db: Session,
    data: LeadCreate,
) -> Lead:

    customer = db.get(
        Customer,
        data.customer_id,
    )

    if not customer:
        raise HTTPException(
            status_code=404,
            detail="Customer not found",
        )

    if data.property_id is not None:
        property_obj = db.get(
            Property,
            data.property_id,
        )

        if not property_obj:
            raise HTTPException(
                status_code=404,
                detail="Property not found",
            )

    try:
        status_value = LeadStatus(data.status)
    except ValueError:
        raise HTTPException(
            status_code=422,
            detail="Invalid lead status",
        )

    lead = Lead(
        customer_id=data.customer_id,
        property_id=data.property_id,
        agent_id=data.agent_id,
        status=status_value,
        notes=data.notes,
    )

    db.add(lead)

    try:
        db.commit()
        db.refresh(lead)
    except IntegrityError:
        db.rollback()

        raise HTTPException(
            status_code=409,
            detail="Could not create lead",
        )

    return lead


def get_lead(
    db: Session,
    lead_id: int,
) -> Lead:

    lead = db.get(
        Lead,
        lead_id,
    )

    if not lead:
        raise HTTPException(
            status_code=404,
            detail="Lead not found",
        )

    return lead


def get_lead_detail(
    db: Session,
    lead_id: int,
) -> Lead:

    lead = db.execute(
        select(Lead)
        .options(
            joinedload(Lead.customer),
            joinedload(Lead.property),
        )
        .where(Lead.id == lead_id)
    ).unique().scalar_one_or_none()

    if not lead:
        raise HTTPException(
            status_code=404,
            detail="Lead not found",
        )

    return lead


def list_leads(
    db: Session,
    status: str | None = None,
    agent_id: int | None = None,
    customer_id: int | None = None,
    property_id: int | None = None,
    created_after: datetime | None = None,
    page: int = 1,
    page_size: int = 20,
):

    query = select(Lead)

    if status is not None:
        try:
            status_value = LeadStatus(status)
        except ValueError:
            raise HTTPException(
                status_code=422,
                detail="Invalid lead status",
            )

        query = query.where(
            Lead.status == status_value
        )

    if agent_id is not None:
        query = query.where(
            Lead.agent_id == agent_id
        )

    if customer_id is not None:
        query = query.where(
            Lead.customer_id == customer_id
        )

    if property_id is not None:
        query = query.where(
            Lead.property_id == property_id
        )

    if created_after is not None:
        query = query.where(
            Lead.created_at >= created_after
        )

    count_query = select(
        func.count()
    ).select_from(
        query.subquery()
    )

    total = db.execute(
        count_query
    ).scalar_one()

    offset = (page - 1) * page_size

    items = db.execute(
        query
        .order_by(Lead.created_at.desc())
        .offset(offset)
        .limit(page_size)
    ).scalars().all()

    return {
        "total": total,
        "items": items,
    }


def patch_lead(
    db: Session,
    lead_id: int,
    data: LeadUpdate,
) -> Lead:

    lead = get_lead(
        db,
        lead_id,
    )

    updates = data.model_dump(
        exclude_unset=True
    )

    if "customer_id" in updates:

        customer = db.get(
            Customer,
            updates["customer_id"],
        )

        if not customer:
            raise HTTPException(
                status_code=404,
                detail="Customer not found",
            )

    if "property_id" in updates and updates["property_id"] is not None:

        property_obj = db.get(
            Property,
            updates["property_id"],
        )

        if not property_obj:
            raise HTTPException(
                status_code=404,
                detail="Property not found",
            )

    if "status" in updates:

        try:
            updates["status"] = LeadStatus(
                updates["status"]
            )
        except ValueError:
            raise HTTPException(
                status_code=422,
                detail="Invalid lead status",
            )

    for field, value in updates.items():
        setattr(
            lead,
            field,
            value,
        )

    db.commit()
    db.refresh(lead)

    return lead


def delete_lead(
    db: Session,
    lead_id: int,
):

    lead = get_lead(
        db,
        lead_id,
    )

    db.delete(lead)
    db.commit()